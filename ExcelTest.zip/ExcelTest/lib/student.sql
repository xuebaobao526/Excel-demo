CREATE DATABASE /*!32312 IF NOT EXISTS*/`xapi` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `test_lyx`;
/*Table structure for table `api_user_info` */
DROP TABLE IF EXISTS `student_info`;
CREATE TABLE `student_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `no` varchar(20) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `age` varchar(10) DEFAULT NULL,
  `score` float DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


