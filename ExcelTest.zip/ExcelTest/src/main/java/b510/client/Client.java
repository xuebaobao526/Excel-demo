/**
 * 
 */
package main.java.b510.client;

import java.io.IOException;
import java.sql.SQLException;

import main.java.b510.excel.SaveData2DB;

/**
 * 测试将excel文件读到数据库的功能
 */
public class Client {

	public static void main(String[] args) throws IOException, SQLException {
		SaveData2DB saveData2DB = new SaveData2DB();
		saveData2DB.save();
		System.out.println("end");
	}
}
